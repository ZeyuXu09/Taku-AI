import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import 'analysis_result.dart';

/// Contract for every exercise coach.
///
/// One analyzer instance lives for the duration of a workout and is fed each
/// detected [Pose]. It holds the rep count / hold timer / feedback state
/// internally — the equivalent of the per-exercise `analyze_*` functions in the
/// Python project, but as reusable objects instead of blocking `while` loops.
abstract class ExerciseAnalyzer {
  /// `true` for held poses (plank, downward dog) where we track hold-time
  /// instead of counting reps.
  bool get isStatic;

  /// Process one detected pose. [now] is passed in (rather than read from the
  /// clock inside) so timing is testable and consistent within a frame.
  AnalysisResult update(Pose pose, DateTime now);

  /// Clear all counters/timers back to the starting state.
  void reset();
}

import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

/// A measured joint angle, with the landmark it's centered on so the overlay
/// can draw the number right at that joint (like the Python `cv2.putText` that
/// printed the angle next to the vertex).
class JointAngle {
  const JointAngle(this.label, this.degrees, this.vertex);

  /// Short name, e.g. "Elbow", "Back", "Leg".
  final String label;

  /// The angle in degrees (0–180).
  final double degrees;

  /// The landmark at the vertex of the angle (where it's drawn).
  final PoseLandmarkType vertex;
}

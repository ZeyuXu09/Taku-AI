import 'joint_angle.dart';

/// The output of an [ExerciseAnalyzer] for a single frame — everything the UI
/// needs to render the heads-up display.
class AnalysisResult {
  const AnalysisResult({
    required this.reps,
    required this.phase,
    required this.poseVisible,
    required this.formGood,
    this.cue,
    this.cueIsNew = false,
    this.holdTime = Duration.zero,
    this.angles = const [],
  });

  /// Blank state before any body is detected.
  const AnalysisResult.waiting()
      : reps = 0,
        phase = 'Get into frame',
        poseVisible = false,
        formGood = false,
        cue = null,
        cueIsNew = false,
        holdTime = Duration.zero,
        angles = const [];

  /// Completed repetitions (0 for static hold poses).
  final int reps;

  /// Human-readable movement phase, e.g. "Up", "Down", "Hold".
  final String phase;

  /// Whether a usable pose was detected this frame.
  final bool poseVisible;

  /// Whether the current body position is within tolerance.
  final bool formGood;

  /// The single most important correction to show, or `null` if form is good.
  final String? cue;

  /// `true` only on the frame a new cue appears (drives a one-shot haptic).
  final bool cueIsNew;

  /// Accumulated time held in good form (only meaningful for static poses).
  final Duration holdTime;

  /// The joint angles measured this frame, for the overlay to display.
  final List<JointAngle> angles;
}

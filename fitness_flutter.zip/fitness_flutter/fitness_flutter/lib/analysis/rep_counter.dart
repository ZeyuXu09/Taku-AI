/// Counts repetitions from a single normalized "contraction" signal.
///
/// The signal is expected in the range 0–100, where **100 = peak contraction**
/// (e.g. bottom of a push-up / top of a curl) and **0 = rest position**.
///
/// This replaces the Python approach of `if percentage == 100 ... elif
/// percentage == 0`, which relied on the metric hitting exact values and
/// double-counted on jitter. Instead we use *hysteresis*: the movement must
/// cross well past a threshold in each direction before it flips state, so
/// small tremors near the threshold never register as reps.
class RepCounter {
  RepCounter({this.enterTop = 80.0, this.enterBottom = 20.0})
      : assert(enterTop > enterBottom);

  /// Signal must reach at least this to be considered "at peak contraction".
  final double enterTop;

  /// Signal must fall to at most this to be considered "back at rest".
  final double enterBottom;

  int reps = 0;
  bool _atTop = false;

  /// Feed one frame's signal. Returns `true` on the frame a rep completes
  /// (i.e. the user returned to rest after reaching peak contraction).
  bool update(double signal) {
    if (signal >= enterTop) {
      _atTop = true;
      return false;
    }
    if (signal <= enterBottom && _atTop) {
      _atTop = false;
      reps++;
      return true;
    }
    return false;
  }

  void reset() {
    reps = 0;
    _atTop = false;
  }
}

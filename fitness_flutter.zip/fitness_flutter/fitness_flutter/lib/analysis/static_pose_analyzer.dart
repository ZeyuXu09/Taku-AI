import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import 'analysis_result.dart';
import 'exercise_analyzer.dart';
import 'feedback_manager.dart';
import 'joint_angle.dart';

/// Base class for held poses (plank, downward dog).
///
/// It accumulates *hold time* — the wall-clock time the user has spent in good
/// form — by summing the gap between consecutive good frames. Subclasses just
/// implement [check] to report, for the current pose, whether form is good and
/// which faults are active.
abstract class StaticPoseAnalyzer extends ExerciseAnalyzer {
  final _feedback = FeedbackManager();
  Duration _hold = Duration.zero;
  DateTime? _lastGoodFrame;

  @override
  bool get isStatic => true;

  /// Returns null when the pose can't be evaluated (body not visible), or a
  /// record of the frame's state otherwise. Faults are in priority order.
  ({
    bool formGood,
    List<Fault> faults,
    String phase,
    List<JointAngle> angles,
  })? check(Pose pose);

  @override
  AnalysisResult update(Pose pose, DateTime now) {
    final result = check(pose);
    if (result == null) {
      _lastGoodFrame = null;
      return const AnalysisResult.waiting();
    }

    if (result.formGood) {
      // Add the elapsed time since the previous good frame. Large gaps (e.g.
      // the user briefly left form) don't count because _lastGoodFrame resets.
      final last = _lastGoodFrame;
      if (last != null) _hold += now.difference(last);
      _lastGoodFrame = now;
    } else {
      _lastGoodFrame = null;
    }

    final decision = _feedback.evaluate(result.faults, now);

    return AnalysisResult(
      reps: 0,
      phase: result.phase,
      poseVisible: true,
      formGood: result.formGood,
      cue: decision.message,
      cueIsNew: decision.isNew,
      holdTime: _hold,
      angles: result.angles,
    );
  }

  @override
  void reset() {
    _feedback.reset();
    _hold = Duration.zero;
    _lastGoodFrame = null;
  }
}

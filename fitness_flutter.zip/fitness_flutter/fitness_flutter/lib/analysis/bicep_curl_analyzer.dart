import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../pose/pose_math.dart';
import 'analysis_result.dart';
import 'exercise_analyzer.dart';
import 'feedback_manager.dart';
import 'joint_angle.dart';
import 'rep_counter.dart';

/// Bicep-curl coach. Port of `bicep_curl.py`.
///
/// Improvement over the Python: rather than a hard-coded `left`/`right` flag,
/// it auto-tracks whichever arm is more clearly visible each frame, and it
/// checks that the upper arm stays pinned (shoulder–elbow near the torso)
/// instead of swinging — a common curl fault.
class BicepCurlAnalyzer extends ExerciseAnalyzer {
  final _reps = RepCounter(enterTop: 80, enterBottom: 20);
  final _feedback = FeedbackManager();

  @override
  bool get isStatic => false;

  @override
  void reset() {
    _reps.reset();
    _feedback.reset();
  }

  @override
  AnalysisResult update(Pose pose, DateTime now) {
    final side = _clearerArm(pose);
    final (shoulder, elbow, wrist, hip) = _joints(side);

    final elbowAngle = PoseMath.angle(pose, shoulder, elbow, wrist);
    // Angle of the upper arm relative to the torso; small = arm stays pinned.
    final upperArmAngle = PoseMath.angle(pose, hip, shoulder, elbow);

    if (elbowAngle == null) {
      return const AnalysisResult.waiting();
    }

    // 100 = fully curled (elbow closed), 0 = fully extended.
    final contraction = PoseMath.mapRange(elbowAngle, 30, 160, 100, 0);
    _reps.update(contraction);

    final armSwinging = upperArmAngle != null && upperArmAngle > 40;

    final decision = _feedback.evaluate([
      Fault('swing', armSwinging, 'Keep your upper arm still'),
    ], now);

    return AnalysisResult(
      reps: _reps.reps,
      phase: contraction >= 50 ? 'Curl' : 'Extend',
      poseVisible: true,
      formGood: !armSwinging,
      cue: decision.message,
      cueIsNew: decision.isNew,
      angles: [
        JointAngle('Elbow', elbowAngle, elbow),
        if (upperArmAngle != null) JointAngle('Arm', upperArmAngle, shoulder),
      ],
    );
  }

  BodySide _clearerArm(Pose pose) {
    final left = PoseMath.averageLikelihood(pose, const [
      PoseLandmarkType.leftShoulder,
      PoseLandmarkType.leftElbow,
      PoseLandmarkType.leftWrist,
    ]);
    final right = PoseMath.averageLikelihood(pose, const [
      PoseLandmarkType.rightShoulder,
      PoseLandmarkType.rightElbow,
      PoseLandmarkType.rightWrist,
    ]);
    return right >= left ? BodySide.right : BodySide.left;
  }

  (PoseLandmarkType, PoseLandmarkType, PoseLandmarkType, PoseLandmarkType)
      _joints(BodySide side) {
    return side == BodySide.right
        ? (
            PoseLandmarkType.rightShoulder,
            PoseLandmarkType.rightElbow,
            PoseLandmarkType.rightWrist,
            PoseLandmarkType.rightHip,
          )
        : (
            PoseLandmarkType.leftShoulder,
            PoseLandmarkType.leftElbow,
            PoseLandmarkType.leftWrist,
            PoseLandmarkType.leftHip,
          );
  }
}

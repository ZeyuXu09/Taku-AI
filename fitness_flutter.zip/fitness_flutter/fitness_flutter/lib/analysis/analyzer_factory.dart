import '../models/exercise.dart';
import 'bicep_curl_analyzer.dart';
import 'downward_dog_analyzer.dart';
import 'exercise_analyzer.dart';
import 'plank_analyzer.dart';
import 'pushup_analyzer.dart';

/// Builds the analyzer for a given exercise — the Dart equivalent of the
/// `if/elif` dispatch inside `FitnessAnalyzer.analyze_exercise`.
ExerciseAnalyzer createAnalyzer(ExerciseType type) => switch (type) {
      ExerciseType.pushup => PushupAnalyzer(),
      ExerciseType.plank => PlankAnalyzer(),
      ExerciseType.bicepCurl => BicepCurlAnalyzer(),
      ExerciseType.downwardDog => DownwardDogAnalyzer(),
    };

/// A single form fault that may be active on a given frame.
class Fault {
  const Fault(this.key, this.active, this.message);

  /// Stable identifier so the manager can track how long it has been active.
  final String key;

  /// Whether the fault is present on this frame.
  final bool active;

  /// The coaching cue to surface if this fault persists.
  final String message;
}

/// Result of evaluating the current faults.
class FeedbackDecision {
  const FeedbackDecision(this.message, this.isNew);

  /// The cue to display, or `null` if the user's form is currently fine.
  final String? message;

  /// `true` the first frame a *new* cue becomes active (used to trigger a
  /// haptic buzz without spamming it every frame).
  final bool isNew;
}

/// Decides which coaching cue (if any) to show.
///
/// The Python code counted raw frames (`e == n_frame_in_two_sec`) which is
/// frame-rate dependent and, in a few places, reset the wrong counter. This
/// uses wall-clock time instead: a fault must persist continuously for [hold]
/// before it's surfaced, and faults are evaluated in priority order so only the
/// single most important cue is shown at a time.
class FeedbackManager {
  FeedbackManager({this.hold = const Duration(milliseconds: 1200)});

  /// How long a fault must persist before its cue is shown.
  final Duration hold;

  final Map<String, DateTime> _activeSince = {};
  String? _lastMessage;

  /// Evaluate [faults] (highest priority first) at time [now].
  FeedbackDecision evaluate(List<Fault> faults, DateTime now) {
    final stillActive = <String>{};
    String? emit;

    for (final fault in faults) {
      if (!fault.active) continue;
      stillActive.add(fault.key);
      final since = _activeSince.putIfAbsent(fault.key, () => now);
      if (emit == null && now.difference(since) >= hold) {
        emit = fault.message;
      }
    }

    // Forget faults that are no longer active so their timers restart cleanly.
    _activeSince.removeWhere((key, _) => !stillActive.contains(key));

    final isNew = emit != null && emit != _lastMessage;
    _lastMessage = emit;
    return FeedbackDecision(emit, isNew);
  }

  void reset() {
    _activeSince.clear();
    _lastMessage = null;
  }
}

import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../pose/pose_math.dart';
import 'feedback_manager.dart';
import 'joint_angle.dart';
import 'static_pose_analyzer.dart';

/// Plank coach. Port of `plank.py`.
///
/// Good form = forearms roughly vertical under the shoulders (elbow ~90°), body
/// in a straight line (hip ~180°) and legs straight. Reports the highest
/// priority correction when any of those drift out of tolerance.
class PlankAnalyzer extends StaticPoseAnalyzer {
  @override
  ({
    bool formGood,
    List<Fault> faults,
    String phase,
    List<JointAngle> angles,
  })? check(Pose pose) {
    final side = _clearerSide(pose);
    final (shoulder, elbow, wrist, hip, knee, ankle) = _joints(side);

    final elbowAngle = PoseMath.angle(pose, shoulder, elbow, wrist);
    final hipAngle = PoseMath.angle(pose, shoulder, hip, knee);
    final legAngle = PoseMath.angle(pose, hip, knee, ankle);

    if (elbowAngle == null || hipAngle == null || legAngle == null) return null;

    final elbowStacked = elbowAngle >= 75 && elbowAngle <= 105;
    final bodyStraight = hipAngle >= 160;
    final hipsPiked = hipAngle > 195; // (never true for a 0–180 angle, kept for clarity)
    final legsStraight = legAngle > 160;

    final formGood = elbowStacked && bodyStraight && legsStraight;

    final faults = [
      Fault('hipSag', hipAngle < 150, 'Straighten your body — hips in line'),
      Fault('elbow', !elbowStacked, 'Stack your shoulders over your elbows'),
      Fault('legs', !legsStraight, 'Straighten your legs'),
      Fault('pike', hipsPiked, 'Lower your hips'),
    ];

    return (
      formGood: formGood,
      faults: faults,
      phase: formGood ? 'Hold' : 'Fix form',
      angles: [
        JointAngle('Elbow', elbowAngle, elbow),
        JointAngle('Hip', hipAngle, hip),
        JointAngle('Leg', legAngle, knee),
      ],
    );
  }

  BodySide _clearerSide(Pose pose) {
    final left = PoseMath.averageLikelihood(pose, const [
      PoseLandmarkType.leftShoulder,
      PoseLandmarkType.leftHip,
      PoseLandmarkType.leftKnee,
    ]);
    final right = PoseMath.averageLikelihood(pose, const [
      PoseLandmarkType.rightShoulder,
      PoseLandmarkType.rightHip,
      PoseLandmarkType.rightKnee,
    ]);
    return right >= left ? BodySide.right : BodySide.left;
  }

  (
    PoseLandmarkType,
    PoseLandmarkType,
    PoseLandmarkType,
    PoseLandmarkType,
    PoseLandmarkType,
    PoseLandmarkType,
  ) _joints(BodySide side) {
    return side == BodySide.right
        ? (
            PoseLandmarkType.rightShoulder,
            PoseLandmarkType.rightElbow,
            PoseLandmarkType.rightWrist,
            PoseLandmarkType.rightHip,
            PoseLandmarkType.rightKnee,
            PoseLandmarkType.rightAnkle,
          )
        : (
            PoseLandmarkType.leftShoulder,
            PoseLandmarkType.leftElbow,
            PoseLandmarkType.leftWrist,
            PoseLandmarkType.leftHip,
            PoseLandmarkType.leftKnee,
            PoseLandmarkType.leftAnkle,
          );
  }
}

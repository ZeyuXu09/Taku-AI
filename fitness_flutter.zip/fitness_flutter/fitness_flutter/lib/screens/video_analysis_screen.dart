import 'dart:io';

import 'package:camera/camera.dart' show CameraLensDirection;
import 'package:flutter/material.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart'
    show InputImageRotation;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

import '../models/exercise.dart';
import '../pose/pose_painter.dart';
import '../theme.dart';
import '../video/video_analysis_service.dart';

/// Analyzes a pre-recorded video clip and plays it back with the pose estimate,
/// joint angles and coaching cues overlaid in sync — the file-based counterpart
/// to the live [WorkoutScreen], matching how the original Python app ran on
/// sample_videos `.mp4` files.
class VideoAnalysisScreen extends StatefulWidget {
  const VideoAnalysisScreen({super.key, required this.exercise});

  final ExerciseType exercise;

  @override
  State<VideoAnalysisScreen> createState() => _VideoAnalysisScreenState();
}

enum _Stage { idle, processing, done, error }

class _VideoAnalysisScreenState extends State<VideoAnalysisScreen> {
  final _service = VideoAnalysisService();
  final _picker = ImagePicker();

  _Stage _stage = _Stage.idle;
  double _progress = 0;
  String? _error;
  VideoAnalysisSummary? _summary;

  Future<void> _pickAndAnalyze() async {
    final picked = await _picker.pickVideo(source: ImageSource.gallery);
    if (picked == null) return;

    setState(() {
      _stage = _Stage.processing;
      _progress = 0;
      _error = null;
      _summary = null;
    });

    try {
      final summary = await _service.analyze(
        videoPath: picked.path,
        exercise: widget.exercise,
        onProgress: (p) {
          if (mounted) setState(() => _progress = p);
        },
      );
      if (mounted) {
        setState(() {
          _summary = summary;
          _stage = _Stage.done;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = '$e';
          _stage = _Stage.error;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.exercise.title} · Video')),
      body: switch (_stage) {
        _Stage.idle => _Intro(exercise: widget.exercise, onPick: _pickAndAnalyze),
        _Stage.processing => _Progress(progress: _progress),
        _Stage.error => _ErrorView(
            message: _error ?? 'Something went wrong',
            onRetry: _pickAndAnalyze,
          ),
        _Stage.done => _Player(
            // Key by path so switching clips rebuilds the player fresh.
            key: ValueKey(_summary!.videoPath),
            summary: _summary!,
            onAnalyzeAnother: _pickAndAnalyze,
          ),
      },
    );
  }
}

class _Intro extends StatelessWidget {
  const _Intro({required this.exercise, required this.onPick});

  final ExerciseType exercise;
  final VoidCallback onPick;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(exercise.icon,
                size: 72, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 16),
            Text(
              'Analyze a ${exercise.title.toLowerCase()} video',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Pick a clip from your gallery. The whole body should stay in '
              'frame, filmed from the side.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textDim, height: 1.35),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onPick,
              icon: const Icon(Icons.video_library),
              label: const Text('Choose video'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Progress extends StatelessWidget {
  const _Progress({required this.progress});
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 72,
            height: 72,
            child: CircularProgressIndicator(
                value: progress == 0 ? null : progress),
          ),
          const SizedBox(height: 16),
          Text('Analyzing… ${(progress * 100).round()}%'),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: Colors.redAccent),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }
}

/// Plays the analyzed clip with the skeleton / angles / cue drawn on top,
/// synced to the current playback position.
class _Player extends StatefulWidget {
  const _Player({super.key, required this.summary, required this.onAnalyzeAnother});

  final VideoAnalysisSummary summary;
  final VoidCallback onAnalyzeAnother;

  @override
  State<_Player> createState() => _PlayerState();
}

class _PlayerState extends State<_Player> {
  late final VideoPlayerController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(File(widget.summary.videoPath));
    _controller.initialize().then((_) {
      if (!mounted) return;
      _controller.setLooping(true);
      setState(() => _ready = true);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _togglePlay() {
    setState(() {
      _controller.value.isPlaying ? _controller.pause() : _controller.play();
    });
  }

  @override
  Widget build(BuildContext context) {
    final summary = widget.summary;
    final isStatic = summary.exercise.isStatic;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _VideoWithOverlay(
          controller: _controller,
          summary: summary,
          ready: _ready,
          onTap: _togglePlay,
        ),
        const SizedBox(height: 8),
        if (_ready) _Controls(controller: _controller, onPlayPause: _togglePlay),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _MetricTile(
                label: isStatic ? 'Good-form time' : 'Reps',
                value: isStatic
                    ? _fmt(summary.goodFormTime)
                    : '${summary.totalReps}',
                icon: isStatic ? Icons.timer : Icons.repeat,
                colors: summary.exercise.colors,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _MetricTile(
                label: 'Form score',
                value: '${(summary.formScore * 100).round()}%',
                icon: Icons.verified,
                colors: const ExerciseColors(
                    Color(0xFF34D399), Color(0xFF10B981)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 22),
        const _SectionTitle('Coaching cues'),
        const SizedBox(height: 8),
        if (summary.cues.isEmpty)
          _CueTile.good()
        else
          for (final cue in summary.cues)
            _CueTile(
              message: cue.message,
              time: _fmt(cue.time),
              onTap: () => _controller.seekTo(cue.time),
            ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: widget.onAnalyzeAnother,
          icon: const Icon(Icons.video_library),
          label: const Text('Analyze another video'),
        ),
      ],
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _VideoWithOverlay extends StatelessWidget {
  const _VideoWithOverlay({
    required this.controller,
    required this.summary,
    required this.ready,
    required this.onTap,
  });

  final VideoPlayerController controller;
  final VideoAnalysisSummary summary;
  final bool ready;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    if (!ready) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Colors.black,
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: GestureDetector(
          onTap: onTap,
          child: ValueListenableBuilder<VideoPlayerValue>(
            valueListenable: controller,
            builder: (context, value, _) {
              final frame = summary.frameAt(value.position.inMilliseconds);
              return Stack(
                fit: StackFit.expand,
                children: [
                  VideoPlayer(controller),
                  CustomPaint(
                    painter: PosePainter(
                      pose: frame?.pose,
                      imageSize: summary.frameSize,
                      // Extracted frames are upright and un-mirrored.
                      rotation: InputImageRotation.rotation0deg,
                      cameraLensDirection: CameraLensDirection.back,
                      formGood: frame?.formGood ?? false,
                      angles: frame?.angles ?? const [],
                    ),
                  ),
                  if (frame != null) _FrameHud(frame: frame, isStatic: summary.exercise.isStatic),
                  if (!value.isPlaying)
                    const Center(
                      child: Icon(Icons.play_circle_fill,
                          size: 64, color: Colors.white70),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Rep/phase chip and cue banner drawn over the video.
class _FrameHud extends StatelessWidget {
  const _FrameHud({required this.frame, required this.isStatic});

  final FrameAnalysis frame;
  final bool isStatic;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          top: 10,
          left: 10,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              isStatic
                  ? '${frame.phase} · ${_fmt(frame.holdTime)}'
                  : '${frame.reps} reps · ${frame.phase}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
        if (frame.cue != null)
          Positioned(
            left: 10,
            right: 10,
            bottom: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFB45309).withValues(alpha: 0.92),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      frame.cue!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _Controls extends StatelessWidget {
  const _Controls({required this.controller, required this.onPlayPause});

  final VideoPlayerController controller;
  final VoidCallback onPlayPause;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: controller,
          builder: (context, value, _) => IconButton(
            onPressed: onPlayPause,
            icon: Icon(value.isPlaying ? Icons.pause : Icons.play_arrow),
          ),
        ),
        Expanded(
          child: VideoProgressIndicator(
            controller,
            allowScrubbing: true,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ],
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.colors,
  });
  final String label;
  final String value;
  final IconData icon;
  final ExerciseColors colors;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colors.base.withValues(alpha: 0.35)),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [colors.base.withValues(alpha: 0.20), AppTheme.surface],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: colors.base),
          const SizedBox(height: 10),
          Text(value,
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w800,
                color: Colors.white,
              )),
          Text(label, style: const TextStyle(color: AppTheme.textDim)),
        ],
      ),
    );
  }
}

class _CueTile extends StatelessWidget {
  const _CueTile({required this.message, required this.time, this.onTap})
      : good = false;
  const _CueTile.good()
      : message = 'No form issues detected — nice work!',
        time = '',
        onTap = null,
        good = true;

  final String message;
  final String time;
  final VoidCallback? onTap;
  final bool good;

  @override
  Widget build(BuildContext context) {
    final color = good ? AppTheme.good : AppTheme.warn;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Icon(good ? Icons.check_circle : Icons.error_outline,
                    color: color, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(message,
                      style: const TextStyle(color: Colors.white)),
                ),
                if (time.isNotEmpty)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(time,
                        style: const TextStyle(
                            color: AppTheme.textDim,
                            fontSize: 12,
                            fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Text(
        text.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
          color: AppTheme.textDim,
        ),
      );
}

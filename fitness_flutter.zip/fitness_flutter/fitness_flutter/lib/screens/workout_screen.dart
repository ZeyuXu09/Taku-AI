import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../analysis/analysis_result.dart';
import '../analysis/analyzer_factory.dart';
import '../analysis/exercise_analyzer.dart';
import '../models/exercise.dart';
import '../pose/pose_camera_view.dart';
import '../theme.dart';

/// The live coaching screen: camera + skeleton overlay + a heads-up display of
/// reps / hold-time / phase, plus a coaching-cue banner. Replaces the on-screen
/// `cv2.putText` overlays and the spoken feedback from the Python app (with
/// haptics standing in for the removed voice).
class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key, required this.exercise});

  final ExerciseType exercise;

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  late final ExerciseAnalyzer _analyzer = createAnalyzer(widget.exercise);
  AnalysisResult _result = const AnalysisResult.waiting();

  void _onPose(Pose? pose) {
    if (pose == null) {
      if (mounted) setState(() => _result = const AnalysisResult.waiting());
      return;
    }
    final result = _analyzer.update(pose, DateTime.now());

    // Haptics replace the removed voice: a light buzz per rep, a stronger one
    // when a new correction appears.
    if (result.reps > _result.reps) HapticFeedback.mediumImpact();
    if (result.cueIsNew) HapticFeedback.heavyImpact();

    if (mounted) setState(() => _result = result);
  }

  void _reset() {
    _analyzer.reset();
    setState(() => _result = const AnalysisResult.waiting());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(widget.exercise.title),
        actions: [
          IconButton(
            tooltip: 'Reset',
            onPressed: _reset,
            icon: const Icon(Icons.refresh),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          PoseCameraView(
            onPose: _onPose,
            formGood: _result.formGood,
            angles: _result.angles,
          ),
          _Hud(exercise: widget.exercise, result: _result),
        ],
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.exercise, required this.result});

  final ExerciseType exercise;
  final AnalysisResult result;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: kToolbarHeight + 4),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _StatBar(exercise: exercise, result: result),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: _StatusBanner(result: result),
          ),
        ],
      ),
    );
  }
}

/// A frosted-glass bar showing the primary metric, phase and form status.
class _StatBar extends StatelessWidget {
  const _StatBar({required this.exercise, required this.result});

  final ExerciseType exercise;
  final AnalysisResult result;

  @override
  Widget build(BuildContext context) {
    final isStatic = exercise.isStatic;
    final bigValue =
        isStatic ? _formatDuration(result.holdTime) : '${result.reps}';
    final accent = exercise.colors.base;

    return _Glass(
      child: Row(
        children: [
          _metric(isStatic ? 'HOLD' : 'REPS', bigValue, accent),
          Container(
            width: 1,
            height: 40,
            color: Colors.white.withValues(alpha: 0.12),
            margin: const EdgeInsets.symmetric(horizontal: 16),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('PHASE',
                    style: TextStyle(
                        color: AppTheme.textDim,
                        fontSize: 11,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  result.phase,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          _FormDot(
            visible: result.poseVisible,
            good: result.formGood,
          ),
        ],
      ),
    );
  }

  Widget _metric(String label, String value, Color accent) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: AppTheme.textDim,
                fontSize: 11,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700)),
        Text(
          value,
          style: TextStyle(
            color: accent,
            fontSize: 40,
            height: 1.05,
            fontWeight: FontWeight.w800,
            fontFeatures: const [FontFeature.tabularFigures()],
          ),
        ),
      ],
    );
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _FormDot extends StatelessWidget {
  const _FormDot({required this.visible, required this.good});
  final bool visible;
  final bool good;

  @override
  Widget build(BuildContext context) {
    final color = !visible
        ? AppTheme.textDim
        : good
            ? AppTheme.good
            : AppTheme.warn;
    return Container(
      width: 14,
      height: 14,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.6), blurRadius: 8),
        ],
      ),
    );
  }
}

/// Bottom banner: correction cue, good-form confirmation, or a framing hint.
class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.result});

  final AnalysisResult result;

  @override
  Widget build(BuildContext context) {
    final (icon, color, text) = switch (result) {
      _ when result.cue != null => (
          Icons.error_outline,
          AppTheme.warn,
          result.cue!,
        ),
      _ when !result.poseVisible => (
          Icons.accessibility_new,
          AppTheme.textDim,
          'Step back so your whole body is in view',
        ),
      _ when result.formGood => (
          Icons.check_circle_outline,
          AppTheme.good,
          'Good form',
        ),
      _ => (Icons.circle_outlined, AppTheme.textDim, 'Keep going'),
    };

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: _Glass(
        key: ValueKey(text),
        tint: color,
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Reusable frosted-glass container.
class _Glass extends StatelessWidget {
  const _Glass({super.key, required this.child, this.tint});

  final Widget child;
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.38),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: (tint ?? Colors.white).withValues(alpha: 0.22),
            ),
          ),
          child: child,
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:flutter/painting.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import '../analysis/analysis_result.dart';
import '../analysis/analyzer_factory.dart';
import '../analysis/joint_angle.dart';
import '../models/exercise.dart';

/// A coaching cue that fired at a point in the clip.
class CueEvent {
  const CueEvent(this.time, this.message);
  final Duration time;
  final String message;
}

/// The analysis for one sampled frame, kept so the player can overlay the
/// skeleton, angles and cue in sync with playback. No image bytes are stored —
/// the real video is replayed and this is drawn on top.
class FrameAnalysis {
  const FrameAnalysis({
    required this.timeMs,
    required this.pose,
    required this.angles,
    required this.formGood,
    required this.phase,
    required this.reps,
    required this.holdTime,
    this.cue,
  });

  final int timeMs;
  final Pose? pose;
  final List<JointAngle> angles;
  final bool formGood;
  final String phase;
  final int reps;
  final Duration holdTime;
  final String? cue;
}

/// Everything the results screen needs after a clip is analyzed.
class VideoAnalysisSummary {
  const VideoAnalysisSummary({
    required this.exercise,
    required this.videoPath,
    required this.frameSize,
    required this.totalReps,
    required this.goodFormTime,
    required this.framesProcessed,
    required this.framesWithBody,
    required this.formScore,
    required this.cues,
    required this.timeline,
  });

  final ExerciseType exercise;
  final String videoPath;

  /// Pixel size of the sampled frames — the coordinate space the poses live in.
  final Size frameSize;
  final int totalReps;
  final Duration goodFormTime;
  final int framesProcessed;
  final int framesWithBody;

  /// Fraction (0–1) of body-visible frames that were in good form.
  final double formScore;
  final List<CueEvent> cues;

  /// All sampled frames in time order, for synced playback overlay.
  final List<FrameAnalysis> timeline;

  /// The frame whose timestamp is at or just before [positionMs] (or null if
  /// none). Used to sync the overlay to the current playback position.
  FrameAnalysis? frameAt(int positionMs) {
    if (timeline.isEmpty) return null;
    var lo = 0;
    var hi = timeline.length - 1;
    FrameAnalysis? best;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (timeline[mid].timeMs <= positionMs) {
        best = timeline[mid];
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return best ?? timeline.first;
  }
}

/// Runs the same per-frame analysis as the live camera, but over a pre-recorded
/// video file instead of a camera stream.
///
/// ML Kit can't ingest an `.mp4` directly, so we sample_videos frames with
/// [VideoThumbnail] (which wraps the OS-native frame grabbers) and run
/// single-image pose detection on each. Because the analyzers take an injected
/// timestamp, we feed them synthetic frame times so rep-counting and the
/// time-based feedback logic behave exactly as they do live.
class VideoAnalysisService {
  /// Never sample_videos more than this many frames, so a long clip stays responsive.
  static const _maxFrames = 240;

  Future<VideoAnalysisSummary> analyze({
    required String videoPath,
    required ExerciseType exercise,
    double fps = 8,
    void Function(double progress)? onProgress,
  }) async {
    final duration = await _readDuration(videoPath);
    final totalMs = duration.inMilliseconds;

    var stepMs = (1000 / fps).round();
    if (totalMs > 0 && totalMs ~/ stepMs > _maxFrames) {
      stepMs = totalMs ~/ _maxFrames;
    }

    final detector = PoseDetector(
      options: PoseDetectorOptions(mode: PoseDetectionMode.single),
    );
    final analyzer = createAnalyzer(exercise);
    analyzer.reset();
    final tempDir = Directory.systemTemp;
    final base = DateTime(2020);

    var framesWithBody = 0;
    var goodFrames = 0;
    var lastReps = 0;
    var lastHold = Duration.zero;
    Size frameSize = Size.zero;
    String? lastCue;
    final cues = <CueEvent>[];
    final timeline = <FrameAnalysis>[];

    try {
      var index = 0;
      for (var t = 0; t <= totalMs || (totalMs == 0 && t == 0); t += stepMs) {
        final framePath = '${tempDir.path}/pose_frame_$index.jpg';
        final path = await VideoThumbnail.thumbnailFile(
          video: videoPath,
          thumbnailPath: framePath,
          imageFormat: ImageFormat.JPEG,
          maxWidth: 720,
          quality: 90,
          timeMs: t,
        );

        if (path != null) {
          if (frameSize == Size.zero) {
            frameSize = await _imageSize(path);
          }
          final poses =
              await detector.processImage(InputImage.fromFilePath(path));
          final pose = poses.isEmpty ? null : poses.first;
          final now = base.add(Duration(milliseconds: t));
          final result = pose == null
              ? const AnalysisResult.waiting()
              : analyzer.update(pose, now);

          if (result.poseVisible) {
            framesWithBody++;
            if (result.formGood) goodFrames++;
          }
          lastReps = result.reps;
          lastHold = result.holdTime;

          // Record a cue only when it changes (dedupe consecutive frames).
          if (result.cue != lastCue) {
            if (result.cue != null) {
              cues.add(CueEvent(Duration(milliseconds: t), result.cue!));
            }
            lastCue = result.cue;
          }

          timeline.add(FrameAnalysis(
            timeMs: t,
            pose: pose,
            angles: result.angles,
            formGood: result.formGood,
            phase: result.phase,
            reps: result.reps,
            holdTime: result.holdTime,
            cue: result.cue,
          ));

          try {
            await File(path).delete();
          } catch (_) {}
        }

        if (onProgress != null && totalMs > 0) {
          onProgress((t / totalMs).clamp(0.0, 1.0));
        }
        index++;
      }
    } finally {
      await detector.close();
    }
    onProgress?.call(1.0);

    return VideoAnalysisSummary(
      exercise: exercise,
      videoPath: videoPath,
      frameSize: frameSize == Size.zero ? const Size(720, 1280) : frameSize,
      totalReps: lastReps,
      goodFormTime: lastHold,
      framesProcessed: timeline.length,
      framesWithBody: framesWithBody,
      formScore: framesWithBody == 0 ? 0 : goodFrames / framesWithBody,
      cues: cues,
      timeline: timeline,
    );
  }

  Future<Duration> _readDuration(String path) async {
    final controller = VideoPlayerController.file(File(path));
    try {
      await controller.initialize();
      return controller.value.duration;
    } catch (_) {
      return Duration.zero;
    } finally {
      await controller.dispose();
    }
  }

  Future<Size> _imageSize(String path) async {
    final bytes = await File(path).readAsBytes();
    final image = await decodeImageFromList(bytes);
    final size = Size(image.width.toDouble(), image.height.toDouble());
    image.dispose();
    return size;
  }
}

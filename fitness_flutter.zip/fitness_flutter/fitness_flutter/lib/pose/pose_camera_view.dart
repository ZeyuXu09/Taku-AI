import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../analysis/joint_angle.dart';
import 'pose_painter.dart';

/// A live camera preview that runs on-device pose detection on each frame and
/// paints the detected skeleton on top.
///
/// This replaces the Python `cv2.VideoCapture` loop + `PoseDetector`: instead of
/// a blocking `while` loop reading a file, frames arrive via the camera image
/// stream and are processed one at a time (dropping frames while busy so the UI
/// never backs up).
class PoseCameraView extends StatefulWidget {
  const PoseCameraView({
    super.key,
    required this.onPose,
    required this.formGood,
    this.angles = const [],
  });

  /// Called with each detected pose (or `null` when no body is found).
  final void Function(Pose? pose) onPose;

  /// Whether the latest analysis considered form good (controls skeleton color).
  final bool formGood;

  /// Joint angles to label on the skeleton.
  final List<JointAngle> angles;

  @override
  State<PoseCameraView> createState() => _PoseCameraViewState();
}

class _PoseCameraViewState extends State<PoseCameraView>
    with WidgetsBindingObserver {
  final _detector = PoseDetector(options: PoseDetectorOptions());

  List<CameraDescription> _cameras = const [];
  CameraController? _controller;
  int _cameraIndex = -1;
  bool _busy = false;
  bool _disposed = false;

  Pose? _pose;
  Size _imageSize = Size.zero;
  InputImageRotation _rotation = InputImageRotation.rotation0deg;

  // Maps the device's UI orientation to a rotation, used on Android.
  static const _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _setup();
  }

  Future<void> _setup() async {
    _cameras = await availableCameras();
    // Prefer the front camera so users can watch themselves.
    _cameraIndex = _cameras.indexWhere(
      (c) => c.lensDirection == CameraLensDirection.front,
    );
    if (_cameraIndex < 0) _cameraIndex = 0;
    if (_cameras.isNotEmpty) await _startController();
  }

  Future<void> _startController() async {
    final camera = _cameras[_cameraIndex];
    final controller = CameraController(
      camera,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup:
          Platform.isAndroid ? ImageFormatGroup.nv21 : ImageFormatGroup.bgra8888,
    );
    _controller = controller;
    await controller.initialize();
    if (_disposed) return;
    await controller.startImageStream(_processImage);
    if (mounted) setState(() {});
  }

  Future<void> _switchCamera() async {
    if (_cameras.length < 2) return;
    await _controller?.stopImageStream();
    await _controller?.dispose();
    _controller = null;
    _cameraIndex = (_cameraIndex + 1) % _cameras.length;
    await _startController();
  }

  Future<void> _processImage(CameraImage image) async {
    if (_busy || _disposed) return;
    _busy = true;
    final input = _toInputImage(image);
    if (input == null) {
      _busy = false;
      return;
    }
    try {
      final poses = await _detector.processImage(input);
      final pose = poses.isEmpty ? null : poses.first;
      widget.onPose(pose);
      if (!_disposed && mounted) {
        setState(() => _pose = pose);
      }
    } finally {
      _busy = false;
    }
  }

  InputImage? _toInputImage(CameraImage image) {
    final controller = _controller;
    if (controller == null) return null;
    final camera = _cameras[_cameraIndex];
    final sensorOrientation = camera.sensorOrientation;

    InputImageRotation? rotation;
    if (Platform.isIOS) {
      rotation = InputImageRotationValue.fromRawValue(sensorOrientation);
    } else {
      var compensation = _orientations[controller.value.deviceOrientation];
      if (compensation == null) return null;
      if (camera.lensDirection == CameraLensDirection.front) {
        compensation = (sensorOrientation + compensation) % 360;
      } else {
        compensation = (sensorOrientation - compensation + 360) % 360;
      }
      rotation = InputImageRotationValue.fromRawValue(compensation);
    }
    if (rotation == null) return null;

    final format = InputImageFormatValue.fromRawValue(image.format.raw);
    if (format == null ||
        (Platform.isAndroid && format != InputImageFormat.nv21) ||
        (Platform.isIOS && format != InputImageFormat.bgra8888)) {
      return null;
    }
    if (image.planes.length != 1) return null;
    final plane = image.planes.first;

    _imageSize = Size(image.width.toDouble(), image.height.toDouble());
    _rotation = rotation;

    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: _imageSize,
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    if (state == AppLifecycleState.inactive) {
      controller.stopImageStream();
    } else if (state == AppLifecycleState.resumed &&
        !controller.value.isStreamingImages) {
      controller.startImageStream(_processImage);
    }
  }

  @override
  void dispose() {
    _disposed = true;
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    _detector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator()),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: controller.value.previewSize!.height,
            height: controller.value.previewSize!.width,
            child: CameraPreview(controller),
          ),
        ),
        CustomPaint(
          painter: PosePainter(
            pose: _pose,
            imageSize: _imageSize,
            rotation: _rotation,
            cameraLensDirection: _cameras[_cameraIndex].lensDirection,
            formGood: widget.formGood,
            angles: widget.angles,
          ),
        ),
        if (_cameras.length > 1)
          Positioned(
            top: 8,
            right: 8,
            child: SafeArea(
              child: IconButton.filledTonal(
                onPressed: _switchCamera,
                icon: const Icon(Icons.cameraswitch),
              ),
            ),
          ),
      ],
    );
  }
}

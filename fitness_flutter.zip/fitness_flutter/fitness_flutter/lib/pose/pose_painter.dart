import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

import '../analysis/joint_angle.dart';

/// Draws the detected skeleton over the camera preview — the equivalent of
/// OpenCV's `mpDraw.draw_landmarks` in `pose_module.py`.
///
/// The coordinate translation (scaling image-space landmarks onto the canvas,
/// accounting for sensor rotation and front-camera mirroring) follows the
/// approach used in the official google_mlkit example.
class PosePainter extends CustomPainter {
  PosePainter({
    required this.pose,
    required this.imageSize,
    required this.rotation,
    required this.cameraLensDirection,
    required this.formGood,
    this.angles = const [],
  });

  final Pose? pose;
  final Size imageSize;
  final InputImageRotation rotation;
  final CameraLensDirection cameraLensDirection;

  /// Skeleton turns green when form is good, amber when it needs correcting.
  final bool formGood;

  /// Joint angles to label on the skeleton (empty to hide them).
  final List<JointAngle> angles;

  @override
  void paint(Canvas canvas, Size size) {
    final pose = this.pose;
    if (pose == null) return;

    final color = formGood ? const Color(0xFF34D399) : const Color(0xFFFBBF24);

    final jointPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = color;

    final bonePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round
      ..color = color.withValues(alpha: 0.9);

    Offset? project(PoseLandmarkType type) {
      final lm = pose.landmarks[type];
      if (lm == null) return null;
      return Offset(
        _translateX(lm.x, size),
        _translateY(lm.y, size),
      );
    }

    void bone(PoseLandmarkType a, PoseLandmarkType b) {
      final pa = project(a);
      final pb = project(b);
      if (pa != null && pb != null) canvas.drawLine(pa, pb, bonePaint);
    }

    // Torso.
    bone(PoseLandmarkType.leftShoulder, PoseLandmarkType.rightShoulder);
    bone(PoseLandmarkType.leftHip, PoseLandmarkType.rightHip);
    bone(PoseLandmarkType.leftShoulder, PoseLandmarkType.leftHip);
    bone(PoseLandmarkType.rightShoulder, PoseLandmarkType.rightHip);
    // Arms.
    bone(PoseLandmarkType.leftShoulder, PoseLandmarkType.leftElbow);
    bone(PoseLandmarkType.leftElbow, PoseLandmarkType.leftWrist);
    bone(PoseLandmarkType.rightShoulder, PoseLandmarkType.rightElbow);
    bone(PoseLandmarkType.rightElbow, PoseLandmarkType.rightWrist);
    // Legs.
    bone(PoseLandmarkType.leftHip, PoseLandmarkType.leftKnee);
    bone(PoseLandmarkType.leftKnee, PoseLandmarkType.leftAnkle);
    bone(PoseLandmarkType.rightHip, PoseLandmarkType.rightKnee);
    bone(PoseLandmarkType.rightKnee, PoseLandmarkType.rightAnkle);

    for (final lm in pose.landmarks.values) {
      canvas.drawCircle(
        Offset(_translateX(lm.x, size), _translateY(lm.y, size)),
        4,
        jointPaint,
      );
    }

    for (final angle in angles) {
      final vertex = pose.landmarks[angle.vertex];
      if (vertex == null) continue;
      _drawAngleLabel(
        canvas,
        Offset(_translateX(vertex.x, size), _translateY(vertex.y, size)),
        '${angle.degrees.round()}°',
      );
    }
  }

  void _drawAngleLabel(Canvas canvas, Offset at, String text) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    // A translucent chip behind the number so it stays readable over the video.
    final origin = at + const Offset(8, -8);
    final rect = Rect.fromLTWH(
      origin.dx - 4,
      origin.dy - 2,
      tp.width + 8,
      tp.height + 4,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(5)),
      Paint()..color = Colors.black.withValues(alpha: 0.55),
    );
    tp.paint(canvas, origin);
  }

  double _translateX(double x, Size canvasSize) {
    switch (rotation) {
      case InputImageRotation.rotation90deg:
        return x *
            canvasSize.width /
            (Platform.isIOS ? imageSize.width : imageSize.height);
      case InputImageRotation.rotation270deg:
        return canvasSize.width -
            x *
                canvasSize.width /
                (Platform.isIOS ? imageSize.width : imageSize.height);
      case InputImageRotation.rotation0deg:
      case InputImageRotation.rotation180deg:
        final scaled = x * canvasSize.width / imageSize.width;
        return cameraLensDirection == CameraLensDirection.back
            ? scaled
            : canvasSize.width - scaled;
    }
  }

  double _translateY(double y, Size canvasSize) {
    switch (rotation) {
      case InputImageRotation.rotation90deg:
      case InputImageRotation.rotation270deg:
        return y *
            canvasSize.height /
            (Platform.isIOS ? imageSize.height : imageSize.width);
      case InputImageRotation.rotation0deg:
      case InputImageRotation.rotation180deg:
        return y * canvasSize.height / imageSize.height;
    }
  }

  @override
  bool shouldRepaint(covariant PosePainter oldDelegate) {
    return oldDelegate.pose != pose ||
        oldDelegate.formGood != formGood ||
        oldDelegate.angles != angles;
  }
}

import 'dart:math' as math;

import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';

/// Geometry helpers that operate on ML Kit [Pose] landmarks.
///
/// This is the Dart replacement for `pose_module.py`'s `find_angle`, plus a
/// couple of extra utilities the exercise analyzers need.
class PoseMath {
  /// Landmarks below this confidence are treated as "not visible".
  static const double minLikelihood = 0.5;

  PoseMath._();

  /// Interior angle (in degrees, 0–180) at vertex [b] formed by the segments
  /// b→a and b→c. Returns `null` if any of the three landmarks is missing or
  /// too low-confidence to trust.
  ///
  /// Same math as the Python `find_angle` (atan2 of the two segments, then
  /// folded into the 0–180 range) but returns `null` instead of drawing on a
  /// frame, so callers can gracefully skip frames where the body isn't visible.
  static double? angle(
    Pose pose,
    PoseLandmarkType a,
    PoseLandmarkType b,
    PoseLandmarkType c,
  ) {
    final la = pose.landmarks[a];
    final lb = pose.landmarks[b];
    final lc = pose.landmarks[c];
    if (la == null || lb == null || lc == null) return null;
    if (la.likelihood < minLikelihood ||
        lb.likelihood < minLikelihood ||
        lc.likelihood < minLikelihood) {
      return null;
    }

    final radians = math.atan2(lc.y - lb.y, lc.x - lb.x) -
        math.atan2(la.y - lb.y, la.x - lb.x);
    var deg = radians.abs() * 180.0 / math.pi;
    if (deg > 180.0) deg = 360.0 - deg;
    return deg;
  }

  /// Average confidence across a group of landmarks (0–1). Used to decide which
  /// side of the body is more clearly visible for one-sided exercises.
  static double averageLikelihood(Pose pose, List<PoseLandmarkType> types) {
    var sum = 0.0;
    var n = 0;
    for (final t in types) {
      final lm = pose.landmarks[t];
      if (lm != null) {
        sum += lm.likelihood;
        n++;
      }
    }
    return n == 0 ? 0.0 : sum / n;
  }

  /// Linearly maps [value] from the input range to the output range, clamping
  /// to the output bounds. Equivalent to NumPy's `np.interp` as used in the
  /// Python code. Handles reversed ranges (inMin > inMax) correctly.
  static double mapRange(
    double value,
    double inMin,
    double inMax,
    double outMin,
    double outMax,
  ) {
    if (inMin == inMax) return outMin;
    final t = ((value - inMin) / (inMax - inMin)).clamp(0.0, 1.0);
    return outMin + t * (outMax - outMin);
  }
}

/// The two sides of the body, used to auto-select the better-visible arm/leg.
enum BodySide { left, right }

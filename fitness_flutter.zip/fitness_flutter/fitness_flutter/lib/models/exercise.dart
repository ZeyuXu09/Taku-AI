import 'package:flutter/material.dart';

import '../theme.dart';

/// The exercises the app can coach — the Dart equivalent of the four
/// `analyze_*` routines dispatched by the Python `FitnessAnalyzer`.
enum ExerciseType { pushup, plank, bicepCurl, downwardDog }

extension ExerciseInfo on ExerciseType {
  String get title => switch (this) {
        ExerciseType.pushup => 'Push-ups',
        ExerciseType.plank => 'Plank',
        ExerciseType.bicepCurl => 'Bicep Curls',
        ExerciseType.downwardDog => 'Downward Dog',
      };

  String get description => switch (this) {
        ExerciseType.pushup => 'Counts reps and checks back & leg alignment.',
        ExerciseType.plank => 'Holds form on hips, shoulders and legs.',
        ExerciseType.bicepCurl => 'Counts curls and keeps your upper arm still.',
        ExerciseType.downwardDog => 'Guides you into the inverted-V hold.',
      };

  IconData get icon => switch (this) {
        ExerciseType.pushup => Icons.fitness_center,
        ExerciseType.plank => Icons.horizontal_rule,
        ExerciseType.bicepCurl => Icons.sports_mma,
        ExerciseType.downwardDog => Icons.self_improvement,
      };

  /// A one-word category shown as a chip on the card.
  String get tag => isStatic ? 'Hold' : 'Reps';

  /// Signature gradient colors, giving each exercise its own identity.
  ExerciseColors get colors => switch (this) {
        ExerciseType.pushup =>
          const ExerciseColors(Color(0xFFFB923C), Color(0xFFF97316)),
        ExerciseType.plank =>
          const ExerciseColors(Color(0xFF60A5FA), Color(0xFF3B82F6)),
        ExerciseType.bicepCurl =>
          const ExerciseColors(Color(0xFFA78BFA), Color(0xFF8B5CF6)),
        ExerciseType.downwardDog =>
          const ExerciseColors(Color(0xFF34D399), Color(0xFF10B981)),
      };

  /// Held poses track time instead of reps.
  bool get isStatic =>
      this == ExerciseType.plank || this == ExerciseType.downwardDog;
}

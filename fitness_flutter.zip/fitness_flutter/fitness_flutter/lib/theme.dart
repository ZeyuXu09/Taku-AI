import 'package:flutter/material.dart';

/// Central palette + theme for the app. A dark, energetic look that sits well
/// behind the full-screen camera and keeps the whole app visually consistent.
class AppTheme {
  AppTheme._();

  static const Color bg = Color(0xFF0B0F16);
  static const Color surface = Color(0xFF141A23);
  static const Color surfaceHigh = Color(0xFF1E2733);
  static const Color accent = Color(0xFF4F8CFF);
  static const Color good = Color(0xFF22C55E);
  static const Color warn = Color(0xFFF59E0B);
  static const Color textDim = Color(0xFF9AA6B2);

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
    ).copyWith(
      surface: surface,
      surfaceContainerHighest: surfaceHigh,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle:
              const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          side: BorderSide(color: Colors.white.withValues(alpha: 0.15)),
          foregroundColor: Colors.white,
        ),
      ),
    );
  }
}

/// A pair of colors used for each exercise's gradient accents.
class ExerciseColors {
  const ExerciseColors(this.start, this.end);
  final Color start;
  final Color end;

  /// Representative single color (used for icons, borders, tiles).
  Color get base => end;

  List<Color> get gradient => [start, end];
}

package com.codingminds.fitness_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

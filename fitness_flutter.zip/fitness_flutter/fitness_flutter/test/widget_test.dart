import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:fitness_flutter/analysis/rep_counter.dart';
import 'package:fitness_flutter/analysis/feedback_manager.dart';
import 'package:fitness_flutter/models/exercise.dart';
import 'package:fitness_flutter/screens/home_screen.dart';
import 'package:fitness_flutter/video/video_analysis_service.dart';

void main() {
  test('RepCounter counts one rep per full contraction cycle', () {
    final counter = RepCounter(enterTop: 80, enterBottom: 20);
    // Rest -> peak -> rest = one rep.
    counter.update(10); // rest
    counter.update(90); // peak
    expect(counter.reps, 0); // not counted until returning to rest
    counter.update(10); // back to rest
    expect(counter.reps, 1);
    // Jitter near a threshold must not add phantom reps.
    counter.update(19);
    counter.update(21);
    expect(counter.reps, 1);
  });

  test('FeedbackManager only surfaces a fault after it persists', () {
    final manager = FeedbackManager(hold: const Duration(seconds: 1));
    final start = DateTime(2026, 1, 1, 12);
    final faults = [const Fault('back', true, 'Keep your back straight')];

    expect(manager.evaluate(faults, start).message, isNull);
    expect(
      manager
          .evaluate(faults, start.add(const Duration(milliseconds: 1200)))
          .message,
      'Keep your back straight',
    );
  });

  test('VideoAnalysisSummary.frameAt returns the frame at or before a time', () {
    FrameAnalysis frame(int ms) => FrameAnalysis(
          timeMs: ms,
          pose: null,
          angles: const [],
          formGood: true,
          phase: 'Hold',
          reps: 0,
          holdTime: Duration.zero,
        );
    final summary = VideoAnalysisSummary(
      exercise: ExerciseType.plank,
      videoPath: 'x.mp4',
      frameSize: const Size(720, 1280),
      totalReps: 0,
      goodFormTime: Duration.zero,
      framesProcessed: 3,
      framesWithBody: 3,
      formScore: 1,
      cues: const [],
      timeline: [frame(0), frame(100), frame(200)],
    );

    expect(summary.frameAt(50)?.timeMs, 0);
    expect(summary.frameAt(150)?.timeMs, 100);
    expect(summary.frameAt(999)?.timeMs, 200);
  });

  testWidgets('HomeScreen lists all four exercises', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: HomeScreen()));
    expect(find.text('Push-ups'), findsOneWidget);
    expect(find.text('Plank'), findsOneWidget);
    expect(find.text('Bicep Curls'), findsOneWidget);
    expect(find.text('Downward Dog'), findsOneWidget);
  });
}

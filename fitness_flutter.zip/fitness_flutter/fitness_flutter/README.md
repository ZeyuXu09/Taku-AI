# FitForm

An AI fitness form coach for your phone. FitForm watches you exercise through the
camera, counts your reps, times static holds, and gives real-time form
corrections — all on-device, with no server.

It uses `google_mlkit_pose_detection` (the 33-landmark BlazePose model) to track
your body, measures the joint angles that matter for each exercise, and turns
them into rep counts and coaching cues.

## Features

- **Live camera coaching** — a skeleton overlay, the joint angles drawn on your
  body, a rep / hold-time HUD, a coaching-cue banner, and a haptic buzz on each
  rep and each new correction.
- **Analyze a video** — pick a recorded clip and FitForm replays it with the
  skeleton, live joint angles and cues drawn on top, synced to the playhead. You
  also get total reps or good-form time, a form score, and a list of timestamped
  cues you can tap to jump straight to that moment.
- **Four exercises** — push-ups and bicep curls count reps; plank and downward
  dog track how long you hold good form.

Both modes run through one shared analysis core, so the coaching is identical
whether it's live or from a clip.

## How the analysis works

- **Angles** — for each frame, the app computes the interior angle at the joints
  an exercise cares about (e.g. elbow, back/hip, leg) from the pose landmarks.
- **Rep counting** — a hysteresis state machine (`RepCounter`) with separate
  enter-top / enter-bottom thresholds, so small jitter near a threshold never
  produces phantom or double reps.
- **Form feedback** — a wall-clock `FeedbackManager` surfaces a correction only
  after a fault persists (~1.2 s), evaluating faults in priority order so just
  the single most important cue is shown at a time.
- **Auto side-detection** — for one-sided moves it tracks whichever arm/leg is
  more clearly visible, by landmark confidence.

## Project layout

```
lib/
  main.dart                       app entry + theme wiring
  theme.dart                      dark theme + per-exercise colors
  models/exercise.dart            the four exercises + metadata
  pose/
    pose_math.dart                joint-angle geometry
    pose_camera_view.dart         camera stream -> ML Kit -> pose
    pose_painter.dart             skeleton + angle-label overlay
  analysis/
    rep_counter.dart              hysteresis rep counter
    feedback_manager.dart         time-based cue prioritizer
    joint_angle.dart              a measured angle + its vertex
    analysis_result.dart          per-frame analysis output
    exercise_analyzer.dart        analyzer contract
    static_pose_analyzer.dart     hold-time base for plank/dog
    {pushup,plank,bicep_curl,downward_dog}_analyzer.dart
    analyzer_factory.dart         exercise -> analyzer
  video/
    video_analysis_service.dart   frame sampling -> per-frame pose -> report
  screens/
    home_screen.dart              mode toggle + exercise picker
    workout_screen.dart           live camera + HUD + cue banner
    video_analysis_screen.dart    pick clip -> analyze -> playback report
```

## Running

```bash
flutter pub get
flutter run           # on a physical device (camera required)
flutter test          # unit + widget tests
```

Grant the camera permission when prompted (and photo access for video mode).
Prop the phone so your whole body is in frame, filmed from the side.

Requires Android SDK 21+ / iOS 12+.

## Tech

Flutter · `google_mlkit_pose_detection` · `camera` · `video_player` ·
`image_picker` · `video_thumbnail`
